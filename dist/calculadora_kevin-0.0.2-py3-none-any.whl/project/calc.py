from project.calc_kevin.calc_kevin import Calculator

sum = lambda a, b: Calculator.sum(a, b)
sub = lambda a, b: Calculator.sub(a, b)
mul = lambda a, b: Calculator.mul(a, b)
exp = lambda a, b: Calculator.exp(a, b)
root = lambda a, b: Calculator.root(a, b)
div = lambda a, b: Calculator.div(a, b)